#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class UmbrellaAccessToken, UmbrellaAuthAttemptResultBankIdProperties, UmbrellaAuthAttemptResultErrorBackendErrorResponse, UmbrellaAuthAttemptResultErrorIOError, UmbrellaAuthAttemptResultErrorLocalised, UmbrellaAuthAttemptResultErrorUnknownError, UmbrellaAuthAttemptResultOtpProperties, UmbrellaAuthEnvironment, UmbrellaAuthTokenResultErrorBackendErrorResponse, UmbrellaAuthTokenResultErrorIOError, UmbrellaAuthTokenResultErrorUnknownError, UmbrellaAuthTokenResultSuccess, UmbrellaAuthorizationCodeGrant, UmbrellaKotlinAbstractCoroutineContextElement, UmbrellaKotlinAbstractCoroutineContextKey<B, E>, UmbrellaKotlinArray<T>, UmbrellaKotlinByteArray, UmbrellaKotlinByteIterator, UmbrellaKotlinCancellationException, UmbrellaKotlinEnum<E>, UmbrellaKotlinEnumCompanion, UmbrellaKotlinException, UmbrellaKotlinIllegalStateException, UmbrellaKotlinKTypeProjection, UmbrellaKotlinKTypeProjectionCompanion, UmbrellaKotlinKVariance, UmbrellaKotlinNothing, UmbrellaKotlinRuntimeException, UmbrellaKotlinThrowable, UmbrellaKotlinUnit, UmbrellaKotlinx_coroutines_coreCoroutineDispatcher, UmbrellaKotlinx_coroutines_coreCoroutineDispatcherKey, UmbrellaKotlinx_io_coreBuffer, UmbrellaKotlinx_serialization_coreSerialKind, UmbrellaKotlinx_serialization_coreSerializersModule, UmbrellaKtor_client_coreHttpClient, UmbrellaKtor_client_coreHttpClientCall, UmbrellaKtor_client_coreHttpClientCallCompanion, UmbrellaKtor_client_coreHttpClientConfig<T>, UmbrellaKtor_client_coreHttpClientEngineConfig, UmbrellaKtor_client_coreHttpReceivePipeline, UmbrellaKtor_client_coreHttpReceivePipelinePhases, UmbrellaKtor_client_coreHttpRequestBuilder, UmbrellaKtor_client_coreHttpRequestBuilderCompanion, UmbrellaKtor_client_coreHttpRequestData, UmbrellaKtor_client_coreHttpRequestPipeline, UmbrellaKtor_client_coreHttpRequestPipelinePhases, UmbrellaKtor_client_coreHttpResponse, UmbrellaKtor_client_coreHttpResponseContainer, UmbrellaKtor_client_coreHttpResponseData, UmbrellaKtor_client_coreHttpResponsePipeline, UmbrellaKtor_client_coreHttpResponsePipelinePhases, UmbrellaKtor_client_coreHttpSendPipeline, UmbrellaKtor_client_coreHttpSendPipelinePhases, UmbrellaKtor_client_coreProxyConfig, UmbrellaKtor_eventsEventDefinition<T>, UmbrellaKtor_eventsEvents, UmbrellaKtor_httpContentType, UmbrellaKtor_httpContentTypeCompanion, UmbrellaKtor_httpHeaderValueParam, UmbrellaKtor_httpHeaderValueWithParameters, UmbrellaKtor_httpHeaderValueWithParametersCompanion, UmbrellaKtor_httpHeadersBuilder, UmbrellaKtor_httpHttpMethod, UmbrellaKtor_httpHttpMethodCompanion, UmbrellaKtor_httpHttpProtocolVersion, UmbrellaKtor_httpHttpProtocolVersionCompanion, UmbrellaKtor_httpHttpStatusCode, UmbrellaKtor_httpHttpStatusCodeCompanion, UmbrellaKtor_httpOutgoingContent, UmbrellaKtor_httpURLBuilder, UmbrellaKtor_httpURLBuilderCompanion, UmbrellaKtor_httpURLProtocol, UmbrellaKtor_httpURLProtocolCompanion, UmbrellaKtor_httpUrl, UmbrellaKtor_httpUrlCompanion, UmbrellaKtor_utilsAttributeKey<T>, UmbrellaKtor_utilsGMTDate, UmbrellaKtor_utilsGMTDateCompanion, UmbrellaKtor_utilsMonth, UmbrellaKtor_utilsMonthCompanion, UmbrellaKtor_utilsPipeline<TSubject, TContext>, UmbrellaKtor_utilsPipelinePhase, UmbrellaKtor_utilsStringValuesBuilderImpl, UmbrellaKtor_utilsTypeInfo, UmbrellaKtor_utilsWeekDay, UmbrellaKtor_utilsWeekDayCompanion, UmbrellaLoginMethod, UmbrellaLoginStatusResultCompleted, UmbrellaLoginStatusResultException, UmbrellaLoginStatusResultFailed, UmbrellaLoginStatusResultPending, UmbrellaLoginStatusResultPendingBankIdProperties, UmbrellaOtpMarket, UmbrellaRefreshToken, UmbrellaRefreshTokenGrant, UmbrellaResendOtpResultError, UmbrellaResendOtpResultSuccess, UmbrellaRevokeResultError, UmbrellaRevokeResultSuccess, UmbrellaStatusUrl, UmbrellaSubmitOtpResultError, UmbrellaSubmitOtpResultSuccess;

@protocol UmbrellaAuthAttemptResult, UmbrellaAuthAttemptResultError, UmbrellaAuthRepository, UmbrellaAuthTokenResult, UmbrellaAuthTokenResultError, UmbrellaGrant, UmbrellaKotlinAnnotation, UmbrellaKotlinAutoCloseable, UmbrellaKotlinComparable, UmbrellaKotlinContinuation, UmbrellaKotlinContinuationInterceptor, UmbrellaKotlinCoroutineContext, UmbrellaKotlinCoroutineContextElement, UmbrellaKotlinCoroutineContextKey, UmbrellaKotlinFunction, UmbrellaKotlinIterator, UmbrellaKotlinKAnnotatedElement, UmbrellaKotlinKClass, UmbrellaKotlinKClassifier, UmbrellaKotlinKDeclarationContainer, UmbrellaKotlinKType, UmbrellaKotlinMapEntry, UmbrellaKotlinSequence, UmbrellaKotlinSuspendFunction2, UmbrellaKotlinx_coroutines_coreChildHandle, UmbrellaKotlinx_coroutines_coreChildJob, UmbrellaKotlinx_coroutines_coreCoroutineScope, UmbrellaKotlinx_coroutines_coreDisposableHandle, UmbrellaKotlinx_coroutines_coreFlow, UmbrellaKotlinx_coroutines_coreFlowCollector, UmbrellaKotlinx_coroutines_coreJob, UmbrellaKotlinx_coroutines_coreParentJob, UmbrellaKotlinx_coroutines_coreRunnable, UmbrellaKotlinx_coroutines_coreSelectClause, UmbrellaKotlinx_coroutines_coreSelectClause0, UmbrellaKotlinx_coroutines_coreSelectInstance, UmbrellaKotlinx_io_coreRawSink, UmbrellaKotlinx_io_coreRawSource, UmbrellaKotlinx_io_coreSink, UmbrellaKotlinx_io_coreSource, UmbrellaKotlinx_serialization_coreCompositeDecoder, UmbrellaKotlinx_serialization_coreCompositeEncoder, UmbrellaKotlinx_serialization_coreDecoder, UmbrellaKotlinx_serialization_coreDeserializationStrategy, UmbrellaKotlinx_serialization_coreEncoder, UmbrellaKotlinx_serialization_coreKSerializer, UmbrellaKotlinx_serialization_coreSerialDescriptor, UmbrellaKotlinx_serialization_coreSerializationStrategy, UmbrellaKotlinx_serialization_coreSerializersModuleCollector, UmbrellaKtor_client_coreHttpClientEngine, UmbrellaKtor_client_coreHttpClientEngineCapability, UmbrellaKtor_client_coreHttpClientPlugin, UmbrellaKtor_client_coreHttpRequest, UmbrellaKtor_httpHeaders, UmbrellaKtor_httpHttpMessage, UmbrellaKtor_httpHttpMessageBuilder, UmbrellaKtor_httpParameters, UmbrellaKtor_httpParametersBuilder, UmbrellaKtor_ioByteReadChannel, UmbrellaKtor_ioCloseable, UmbrellaKtor_ioJvmSerializable, UmbrellaKtor_utilsAttributes, UmbrellaKtor_utilsStringValues, UmbrellaKtor_utilsStringValuesBuilder, UmbrellaLoginStatusResult, UmbrellaResendOtpResult, UmbrellaRevokeResult, UmbrellaSubmitOtpResult;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface UmbrellaBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface UmbrellaBase (UmbrellaBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface UmbrellaMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface UmbrellaMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorUmbrellaKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface UmbrellaNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface UmbrellaByte : UmbrellaNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface UmbrellaUByte : UmbrellaNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface UmbrellaShort : UmbrellaNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface UmbrellaUShort : UmbrellaNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface UmbrellaInt : UmbrellaNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface UmbrellaUInt : UmbrellaNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface UmbrellaLong : UmbrellaNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface UmbrellaULong : UmbrellaNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface UmbrellaFloat : UmbrellaNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface UmbrellaDouble : UmbrellaNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface UmbrellaBoolean : UmbrellaNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessToken")))
@interface UmbrellaAccessToken : UmbrellaBase
- (instancetype)initWithToken:(NSString *)token expiryInSeconds:(int64_t)expiryInSeconds __attribute__((swift_name("init(token:expiryInSeconds:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAccessToken *)doCopyToken:(NSString *)token expiryInSeconds:(int64_t)expiryInSeconds __attribute__((swift_name("doCopy(token:expiryInSeconds:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t expiryInSeconds __attribute__((swift_name("expiryInSeconds")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@end

__attribute__((swift_name("AuthAttemptResult")))
@protocol UmbrellaAuthAttemptResult
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthAttemptResultBankIdProperties")))
@interface UmbrellaAuthAttemptResultBankIdProperties : UmbrellaBase <UmbrellaAuthAttemptResult>
- (instancetype)initWithId:(NSString *)id statusUrl:(UmbrellaStatusUrl *)statusUrl autoStartToken:(NSString *)autoStartToken __attribute__((swift_name("init(id:statusUrl:autoStartToken:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthAttemptResultBankIdProperties *)doCopyId:(NSString *)id statusUrl:(UmbrellaStatusUrl *)statusUrl autoStartToken:(NSString *)autoStartToken __attribute__((swift_name("doCopy(id:statusUrl:autoStartToken:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *autoStartToken __attribute__((swift_name("autoStartToken")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) UmbrellaStatusUrl *statusUrl __attribute__((swift_name("statusUrl")));
@end

__attribute__((swift_name("AuthAttemptResultError")))
@protocol UmbrellaAuthAttemptResultError <UmbrellaAuthAttemptResult>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthAttemptResultErrorBackendErrorResponse")))
@interface UmbrellaAuthAttemptResultErrorBackendErrorResponse : UmbrellaBase <UmbrellaAuthAttemptResultError>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthAttemptResultErrorBackendErrorResponse *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthAttemptResultErrorIOError")))
@interface UmbrellaAuthAttemptResultErrorIOError : UmbrellaBase <UmbrellaAuthAttemptResultError>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthAttemptResultErrorIOError *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthAttemptResultErrorLocalised")))
@interface UmbrellaAuthAttemptResultErrorLocalised : UmbrellaBase <UmbrellaAuthAttemptResultError>
- (instancetype)initWithReason:(NSString *)reason __attribute__((swift_name("init(reason:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthAttemptResultErrorLocalised *)doCopyReason:(NSString *)reason __attribute__((swift_name("doCopy(reason:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *reason __attribute__((swift_name("reason")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthAttemptResultErrorUnknownError")))
@interface UmbrellaAuthAttemptResultErrorUnknownError : UmbrellaBase <UmbrellaAuthAttemptResultError>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthAttemptResultErrorUnknownError *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthAttemptResultOtpProperties")))
@interface UmbrellaAuthAttemptResultOtpProperties : UmbrellaBase <UmbrellaAuthAttemptResult>
- (instancetype)initWithId:(NSString *)id statusUrl:(UmbrellaStatusUrl *)statusUrl resendUrl:(NSString *)resendUrl verifyUrl:(NSString *)verifyUrl maskedEmail:(NSString * _Nullable)maskedEmail __attribute__((swift_name("init(id:statusUrl:resendUrl:verifyUrl:maskedEmail:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthAttemptResultOtpProperties *)doCopyId:(NSString *)id statusUrl:(UmbrellaStatusUrl *)statusUrl resendUrl:(NSString *)resendUrl verifyUrl:(NSString *)verifyUrl maskedEmail:(NSString * _Nullable)maskedEmail __attribute__((swift_name("doCopy(id:statusUrl:resendUrl:verifyUrl:maskedEmail:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable maskedEmail __attribute__((swift_name("maskedEmail")));
@property (readonly) NSString *resendUrl __attribute__((swift_name("resendUrl")));
@property (readonly) UmbrellaStatusUrl *statusUrl __attribute__((swift_name("statusUrl")));
@property (readonly) NSString *verifyUrl __attribute__((swift_name("verifyUrl")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol UmbrellaKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface UmbrellaKotlinEnum<E> : UmbrellaBase <UmbrellaKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthEnvironment")))
@interface UmbrellaAuthEnvironment : UmbrellaKotlinEnum<UmbrellaAuthEnvironment *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) UmbrellaAuthEnvironment *staging __attribute__((swift_name("staging")));
@property (class, readonly) UmbrellaAuthEnvironment *production __attribute__((swift_name("production")));
+ (UmbrellaKotlinArray<UmbrellaAuthEnvironment *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<UmbrellaAuthEnvironment *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("AuthRepository")))
@protocol UmbrellaAuthRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)exchangeGrant:(id<UmbrellaGrant>)grant completionHandler:(void (^)(id<UmbrellaAuthTokenResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("exchange(grant:completionHandler:)")));
- (id<UmbrellaKotlinx_coroutines_coreFlow>)observeLoginStatusStatusUrl:(UmbrellaStatusUrl *)statusUrl __attribute__((swift_name("observeLoginStatus(statusUrl:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)resendOtpResendUrl:(NSString *)resendUrl completionHandler:(void (^)(id<UmbrellaResendOtpResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("resendOtp(resendUrl:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)revokeToken:(NSString *)token completionHandler:(void (^)(id<UmbrellaRevokeResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("revoke(token:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startLoginAttemptLoginMethod:(UmbrellaLoginMethod *)loginMethod market:(UmbrellaOtpMarket *)market personalNumber:(NSString * _Nullable)personalNumber email:(NSString * _Nullable)email completionHandler:(void (^)(id<UmbrellaAuthAttemptResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startLoginAttempt(loginMethod:market:personalNumber:email:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)submitOtpVerifyUrl:(NSString *)verifyUrl otp:(NSString *)otp completionHandler:(void (^)(id<UmbrellaSubmitOtpResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("submitOtp(verifyUrl:otp:completionHandler:)")));
@end

__attribute__((swift_name("AuthTokenResult")))
@protocol UmbrellaAuthTokenResult
@required
@end

__attribute__((swift_name("AuthTokenResultError")))
@protocol UmbrellaAuthTokenResultError <UmbrellaAuthTokenResult>
@required
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthTokenResultErrorBackendErrorResponse")))
@interface UmbrellaAuthTokenResultErrorBackendErrorResponse : UmbrellaBase <UmbrellaAuthTokenResultError>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthTokenResultErrorBackendErrorResponse *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthTokenResultErrorIOError")))
@interface UmbrellaAuthTokenResultErrorIOError : UmbrellaBase <UmbrellaAuthTokenResultError>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthTokenResultErrorIOError *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthTokenResultErrorUnknownError")))
@interface UmbrellaAuthTokenResultErrorUnknownError : UmbrellaBase <UmbrellaAuthTokenResultError>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthTokenResultErrorUnknownError *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthTokenResultSuccess")))
@interface UmbrellaAuthTokenResultSuccess : UmbrellaBase <UmbrellaAuthTokenResult>
- (instancetype)initWithAccessToken:(UmbrellaAccessToken *)accessToken refreshToken:(UmbrellaRefreshToken *)refreshToken __attribute__((swift_name("init(accessToken:refreshToken:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthTokenResultSuccess *)doCopyAccessToken:(UmbrellaAccessToken *)accessToken refreshToken:(UmbrellaRefreshToken *)refreshToken __attribute__((swift_name("doCopy(accessToken:refreshToken:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) UmbrellaAccessToken *accessToken __attribute__((swift_name("accessToken")));
@property (readonly) UmbrellaRefreshToken *refreshToken __attribute__((swift_name("refreshToken")));
@end

__attribute__((swift_name("Grant")))
@protocol UmbrellaGrant
@required
@property (readonly) NSString *code __attribute__((swift_name("code")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthorizationCodeGrant")))
@interface UmbrellaAuthorizationCodeGrant : UmbrellaBase <UmbrellaGrant>
- (instancetype)initWithCode:(NSString *)code __attribute__((swift_name("init(code:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaAuthorizationCodeGrant *)doCopyCode:(NSString *)code __attribute__((swift_name("doCopy(code:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *code __attribute__((swift_name("code")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginMethod")))
@interface UmbrellaLoginMethod : UmbrellaKotlinEnum<UmbrellaLoginMethod *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) UmbrellaLoginMethod *seBankid __attribute__((swift_name("seBankid")));
@property (class, readonly) UmbrellaLoginMethod *otp __attribute__((swift_name("otp")));
+ (UmbrellaKotlinArray<UmbrellaLoginMethod *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<UmbrellaLoginMethod *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("LoginStatusResult")))
@protocol UmbrellaLoginStatusResult
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginStatusResultCompleted")))
@interface UmbrellaLoginStatusResultCompleted : UmbrellaBase <UmbrellaLoginStatusResult>
- (instancetype)initWithAuthorizationCode:(UmbrellaAuthorizationCodeGrant *)authorizationCode __attribute__((swift_name("init(authorizationCode:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaLoginStatusResultCompleted *)doCopyAuthorizationCode:(UmbrellaAuthorizationCodeGrant *)authorizationCode __attribute__((swift_name("doCopy(authorizationCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) UmbrellaAuthorizationCodeGrant *authorizationCode __attribute__((swift_name("authorizationCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginStatusResultException")))
@interface UmbrellaLoginStatusResultException : UmbrellaBase <UmbrellaLoginStatusResult>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaLoginStatusResultException *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginStatusResultFailed")))
@interface UmbrellaLoginStatusResultFailed : UmbrellaBase <UmbrellaLoginStatusResult>
- (instancetype)initWithLocalisedMessage:(NSString *)localisedMessage __attribute__((swift_name("init(localisedMessage:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaLoginStatusResultFailed *)doCopyLocalisedMessage:(NSString *)localisedMessage __attribute__((swift_name("doCopy(localisedMessage:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *localisedMessage __attribute__((swift_name("localisedMessage")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginStatusResultPending")))
@interface UmbrellaLoginStatusResultPending : UmbrellaBase <UmbrellaLoginStatusResult>
- (instancetype)initWithStatusMessage:(NSString *)statusMessage bankIdProperties:(UmbrellaLoginStatusResultPendingBankIdProperties * _Nullable)bankIdProperties __attribute__((swift_name("init(statusMessage:bankIdProperties:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaLoginStatusResultPending *)doCopyStatusMessage:(NSString *)statusMessage bankIdProperties:(UmbrellaLoginStatusResultPendingBankIdProperties * _Nullable)bankIdProperties __attribute__((swift_name("doCopy(statusMessage:bankIdProperties:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) UmbrellaLoginStatusResultPendingBankIdProperties * _Nullable bankIdProperties __attribute__((swift_name("bankIdProperties")));
@property (readonly) NSString *statusMessage __attribute__((swift_name("statusMessage")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginStatusResultPending.BankIdProperties")))
@interface UmbrellaLoginStatusResultPendingBankIdProperties : UmbrellaBase
- (instancetype)initWithAutoStartToken:(NSString *)autoStartToken liveQrCodeData:(NSString *)liveQrCodeData bankIdAppOpened:(BOOL)bankIdAppOpened __attribute__((swift_name("init(autoStartToken:liveQrCodeData:bankIdAppOpened:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaLoginStatusResultPendingBankIdProperties *)doCopyAutoStartToken:(NSString *)autoStartToken liveQrCodeData:(NSString *)liveQrCodeData bankIdAppOpened:(BOOL)bankIdAppOpened __attribute__((swift_name("doCopy(autoStartToken:liveQrCodeData:bankIdAppOpened:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *autoStartToken __attribute__((swift_name("autoStartToken")));
@property (readonly) BOOL bankIdAppOpened __attribute__((swift_name("bankIdAppOpened")));
@property (readonly) NSString *liveQrCodeData __attribute__((swift_name("liveQrCodeData")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkAuthRepository")))
@interface UmbrellaNetworkAuthRepository : UmbrellaBase <UmbrellaAuthRepository>
- (instancetype)initWithEnvironment:(UmbrellaAuthEnvironment *)environment additionalHttpHeadersProvider:(NSDictionary<NSString *, NSString *> *(^)(void))additionalHttpHeadersProvider httpClientEngine:(id<UmbrellaKtor_client_coreHttpClientEngine> _Nullable)httpClientEngine __attribute__((swift_name("init(environment:additionalHttpHeadersProvider:httpClientEngine:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)exchangeGrant:(id<UmbrellaGrant>)grant completionHandler:(void (^)(id<UmbrellaAuthTokenResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("exchange(grant:completionHandler:)")));
- (id<UmbrellaKotlinx_coroutines_coreFlow>)observeLoginStatusStatusUrl:(UmbrellaStatusUrl *)statusUrl __attribute__((swift_name("observeLoginStatus(statusUrl:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)resendOtpResendUrl:(NSString *)resendUrl completionHandler:(void (^)(id<UmbrellaResendOtpResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("resendOtp(resendUrl:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)revokeToken:(NSString *)token completionHandler:(void (^)(id<UmbrellaRevokeResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("revoke(token:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startLoginAttemptLoginMethod:(UmbrellaLoginMethod *)loginMethod market:(UmbrellaOtpMarket *)market personalNumber:(NSString * _Nullable)personalNumber email:(NSString * _Nullable)email completionHandler:(void (^)(id<UmbrellaAuthAttemptResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startLoginAttempt(loginMethod:market:personalNumber:email:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)submitOtpVerifyUrl:(NSString *)verifyUrl otp:(NSString *)otp completionHandler:(void (^)(id<UmbrellaSubmitOtpResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("submitOtp(verifyUrl:otp:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpMarket")))
@interface UmbrellaOtpMarket : UmbrellaKotlinEnum<UmbrellaOtpMarket *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) UmbrellaOtpMarket *se __attribute__((swift_name("se")));
@property (class, readonly) UmbrellaOtpMarket *no __attribute__((swift_name("no")));
@property (class, readonly) UmbrellaOtpMarket *dk __attribute__((swift_name("dk")));
+ (UmbrellaKotlinArray<UmbrellaOtpMarket *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<UmbrellaOtpMarket *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefreshToken")))
@interface UmbrellaRefreshToken : UmbrellaBase
- (instancetype)initWithToken:(NSString *)token expiryInSeconds:(int64_t)expiryInSeconds __attribute__((swift_name("init(token:expiryInSeconds:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaRefreshToken *)doCopyToken:(NSString *)token expiryInSeconds:(int64_t)expiryInSeconds __attribute__((swift_name("doCopy(token:expiryInSeconds:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t expiryInSeconds __attribute__((swift_name("expiryInSeconds")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefreshTokenGrant")))
@interface UmbrellaRefreshTokenGrant : UmbrellaBase <UmbrellaGrant>
- (instancetype)initWithCode:(NSString *)code __attribute__((swift_name("init(code:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaRefreshTokenGrant *)doCopyCode:(NSString *)code __attribute__((swift_name("doCopy(code:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *code __attribute__((swift_name("code")));
@end

__attribute__((swift_name("ResendOtpResult")))
@protocol UmbrellaResendOtpResult
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResendOtpResultError")))
@interface UmbrellaResendOtpResultError : UmbrellaBase <UmbrellaResendOtpResult>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaResendOtpResultError *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResendOtpResultSuccess")))
@interface UmbrellaResendOtpResultSuccess : UmbrellaBase <UmbrellaResendOtpResult>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaResendOtpResultSuccess *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("RevokeResult")))
@protocol UmbrellaRevokeResult
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RevokeResultError")))
@interface UmbrellaRevokeResultError : UmbrellaBase <UmbrellaRevokeResult>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaRevokeResultError *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RevokeResultSuccess")))
@interface UmbrellaRevokeResultSuccess : UmbrellaBase <UmbrellaRevokeResult>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaRevokeResultSuccess *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StatusUrl")))
@interface UmbrellaStatusUrl : UmbrellaBase
- (instancetype)initWithUrl:(NSString *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaStatusUrl *)doCopyUrl:(NSString *)url __attribute__((swift_name("doCopy(url:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("SubmitOtpResult")))
@protocol UmbrellaSubmitOtpResult
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubmitOtpResultError")))
@interface UmbrellaSubmitOtpResultError : UmbrellaBase <UmbrellaSubmitOtpResult>
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaSubmitOtpResultError *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubmitOtpResultSuccess")))
@interface UmbrellaSubmitOtpResultSuccess : UmbrellaBase <UmbrellaSubmitOtpResult>
- (instancetype)initWithLoginAuthorizationCode:(UmbrellaAuthorizationCodeGrant *)loginAuthorizationCode __attribute__((swift_name("init(loginAuthorizationCode:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaSubmitOtpResultSuccess *)doCopyLoginAuthorizationCode:(UmbrellaAuthorizationCodeGrant *)loginAuthorizationCode __attribute__((swift_name("doCopy(loginAuthorizationCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) UmbrellaAuthorizationCodeGrant *loginAuthorizationCode __attribute__((swift_name("loginAuthorizationCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HelloUmbrella_nativeKt")))
@interface UmbrellaHelloUmbrella_nativeKt : UmbrellaBase
+ (NSString *)helloUmbrella __attribute__((swift_name("helloUmbrella()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface UmbrellaKotlinEnumCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface UmbrellaKotlinArray<T> : UmbrellaBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(UmbrellaInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<UmbrellaKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface UmbrellaKotlinThrowable : UmbrellaBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (UmbrellaKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) UmbrellaKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface UmbrellaKotlinException : UmbrellaKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface UmbrellaKotlinRuntimeException : UmbrellaKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface UmbrellaKotlinIllegalStateException : UmbrellaKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface UmbrellaKotlinCancellationException : UmbrellaKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol UmbrellaKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<UmbrellaKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol UmbrellaKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<UmbrellaKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="2.0")
*/
__attribute__((swift_name("KotlinAutoCloseable")))
@protocol UmbrellaKotlinAutoCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol UmbrellaKtor_ioCloseable <UmbrellaKotlinAutoCloseable>
@required
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol UmbrellaKtor_client_coreHttpClientEngine <UmbrellaKotlinx_coroutines_coreCoroutineScope, UmbrellaKtor_ioCloseable>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(UmbrellaKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(UmbrellaKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));
- (void)installClient:(UmbrellaKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) UmbrellaKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) UmbrellaKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<UmbrellaKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol UmbrellaKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol UmbrellaKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface UmbrellaKtor_client_coreHttpRequestData : UmbrellaBase
- (instancetype)initWithUrl:(UmbrellaKtor_httpUrl *)url method:(UmbrellaKtor_httpHttpMethod *)method headers:(id<UmbrellaKtor_httpHeaders>)headers body:(UmbrellaKtor_httpOutgoingContent *)body executionContext:(id<UmbrellaKotlinx_coroutines_coreJob>)executionContext attributes:(id<UmbrellaKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<UmbrellaKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<UmbrellaKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) UmbrellaKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<UmbrellaKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<UmbrellaKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) UmbrellaKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) UmbrellaKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface UmbrellaKtor_client_coreHttpResponseData : UmbrellaBase
- (instancetype)initWithStatusCode:(UmbrellaKtor_httpHttpStatusCode *)statusCode requestTime:(UmbrellaKtor_utilsGMTDate *)requestTime headers:(id<UmbrellaKtor_httpHeaders>)headers version:(UmbrellaKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<UmbrellaKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<UmbrellaKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<UmbrellaKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) UmbrellaKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) UmbrellaKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) UmbrellaKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface UmbrellaKtor_client_coreHttpClient : UmbrellaBase <UmbrellaKotlinx_coroutines_coreCoroutineScope, UmbrellaKtor_ioCloseable>
- (instancetype)initWithEngine:(id<UmbrellaKtor_client_coreHttpClientEngine>)engine userConfig:(UmbrellaKtor_client_coreHttpClientConfig<UmbrellaKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (UmbrellaKtor_client_coreHttpClient *)configBlock:(void (^)(UmbrellaKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<UmbrellaKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<UmbrellaKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<UmbrellaKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<UmbrellaKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) UmbrellaKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) UmbrellaKtor_eventsEvents *monitor __attribute__((swift_name("monitor")));
@property (readonly) UmbrellaKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) UmbrellaKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) UmbrellaKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) UmbrellaKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface UmbrellaKtor_client_coreHttpClientEngineConfig : UmbrellaBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property UmbrellaKotlinx_coroutines_coreCoroutineDispatcher * _Nullable dispatcher __attribute__((swift_name("dispatcher")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property UmbrellaKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount"))) __attribute__((unavailable("The [threadsCount] property is deprecated. Consider setting [dispatcher] instead.")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol UmbrellaKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<UmbrellaKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<UmbrellaKotlinCoroutineContextElement> _Nullable)getKey:(id<UmbrellaKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<UmbrellaKotlinCoroutineContext>)minusKeyKey:(id<UmbrellaKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<UmbrellaKotlinCoroutineContext>)plusContext:(id<UmbrellaKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol UmbrellaKotlinCoroutineContextElement <UmbrellaKotlinCoroutineContext>
@required
@property (readonly) id<UmbrellaKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface UmbrellaKotlinAbstractCoroutineContextElement : UmbrellaBase <UmbrellaKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<UmbrellaKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<UmbrellaKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol UmbrellaKotlinContinuationInterceptor <UmbrellaKotlinCoroutineContextElement>
@required
- (id<UmbrellaKotlinContinuation>)interceptContinuationContinuation:(id<UmbrellaKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<UmbrellaKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface UmbrellaKotlinx_coroutines_coreCoroutineDispatcher : UmbrellaKotlinAbstractCoroutineContextElement <UmbrellaKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<UmbrellaKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) UmbrellaKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<UmbrellaKotlinCoroutineContext>)context block:(id<UmbrellaKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)dispatchYieldContext:(id<UmbrellaKotlinCoroutineContext>)context block:(id<UmbrellaKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<UmbrellaKotlinContinuation>)interceptContinuationContinuation:(id<UmbrellaKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<UmbrellaKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (UmbrellaKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism name:(NSString * _Nullable)name __attribute__((swift_name("limitedParallelism(parallelism:name:)")));
- (UmbrellaKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(UmbrellaKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<UmbrellaKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol UmbrellaKtor_client_coreHttpClientEngineCapability
@required
@end

__attribute__((swift_name("Ktor_ioJvmSerializable")))
@protocol UmbrellaKtor_ioJvmSerializable
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=io/ktor/http/UrlSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface UmbrellaKtor_httpUrl : UmbrellaBase <UmbrellaKtor_ioJvmSerializable>
@property (class, readonly, getter=companion) UmbrellaKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property (readonly) NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *encodedPathAndQuery __attribute__((swift_name("encodedPathAndQuery")));
@property (readonly) NSString *encodedQuery __attribute__((swift_name("encodedQuery")));
@property (readonly) NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<UmbrellaKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments"))) __attribute__((deprecated("\n        `pathSegments` is deprecated.\n\n        This property will contain an empty path segment at the beginning for URLs with a hostname,\n        and an empty path segment at the end for the URLs with a trailing slash. If you need to keep this behaviour please\n        use [rawSegments]. If you only need to access the meaningful parts of the path, consider using [segments] instead.\n             \n        Please decide if you need [rawSegments] or [segments] explicitly.\n        ")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) UmbrellaKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) UmbrellaKtor_httpURLProtocol * _Nullable protocolOrNull __attribute__((swift_name("protocolOrNull")));
@property (readonly) NSArray<NSString *> *rawSegments __attribute__((swift_name("rawSegments")));
@property (readonly) NSArray<NSString *> *segments __attribute__((swift_name("segments")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface UmbrellaKtor_httpHttpMethod : UmbrellaBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (UmbrellaKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol UmbrellaKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<UmbrellaKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol UmbrellaKtor_httpHeaders <UmbrellaKtor_utilsStringValues>
@required
@end

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface UmbrellaKtor_httpOutgoingContent : UmbrellaBase
- (id _Nullable)getPropertyKey:(UmbrellaKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(UmbrellaKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
- (id<UmbrellaKtor_httpHeaders> _Nullable)trailers __attribute__((swift_name("trailers()")));
@property (readonly) UmbrellaLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) UmbrellaKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<UmbrellaKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol UmbrellaKotlinx_coroutines_coreJob <UmbrellaKotlinCoroutineContextElement>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id<UmbrellaKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<UmbrellaKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause:(UmbrellaKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (UmbrellaKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<UmbrellaKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(UmbrellaKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id<UmbrellaKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(UmbrellaKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<UmbrellaKotlinx_coroutines_coreJob>)plusOther_:(id<UmbrellaKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<UmbrellaKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<UmbrellaKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
@property (readonly) id<UmbrellaKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol UmbrellaKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(UmbrellaKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(UmbrellaKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey_:(UmbrellaKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key_:)")));
- (id _Nullable)getOrNullKey:(UmbrellaKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(UmbrellaKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(UmbrellaKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(UmbrellaKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(UmbrellaKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<UmbrellaKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface UmbrellaKtor_httpHttpStatusCode : UmbrellaBase <UmbrellaKotlinComparable>
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(UmbrellaKtor_httpHttpStatusCode *)other __attribute__((swift_name("compareTo(other:)")));
- (UmbrellaKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (UmbrellaKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface UmbrellaKtor_utilsGMTDate : UmbrellaBase <UmbrellaKotlinComparable>
- (instancetype)initWithSeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(UmbrellaKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(UmbrellaKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("init(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(UmbrellaKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (UmbrellaKtor_utilsGMTDate *)doCopy __attribute__((swift_name("doCopy()")));
- (UmbrellaKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(UmbrellaKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(UmbrellaKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) UmbrellaKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) UmbrellaKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface UmbrellaKtor_httpHttpProtocolVersion : UmbrellaBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (UmbrellaKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface UmbrellaKtor_client_coreHttpClientConfig<T> : UmbrellaBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (UmbrellaKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(UmbrellaKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installPlugin:(id<UmbrellaKtor_client_coreHttpClientPlugin>)plugin configure:(void (^)(id))configure __attribute__((swift_name("install(plugin:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(UmbrellaKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(UmbrellaKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL developmentMode __attribute__((swift_name("developmentMode"))) __attribute__((deprecated("Development mode is no longer required. The property will be removed in the future.")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_eventsEvents")))
@interface UmbrellaKtor_eventsEvents : UmbrellaBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)raiseDefinition:(UmbrellaKtor_eventsEventDefinition<id> *)definition value:(id _Nullable)value __attribute__((swift_name("raise(definition:value:)")));
- (id<UmbrellaKotlinx_coroutines_coreDisposableHandle>)subscribeDefinition:(UmbrellaKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("subscribe(definition:handler:)")));
- (void)unsubscribeDefinition:(UmbrellaKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("unsubscribe(definition:handler:)")));
@end

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface UmbrellaKtor_utilsPipeline<TSubject, TContext> : UmbrellaBase
- (instancetype)initWithPhases:(UmbrellaKotlinArray<UmbrellaKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(UmbrellaKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<UmbrellaKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(UmbrellaKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));
- (void)insertPhaseAfterReference:(UmbrellaKtor_utilsPipelinePhase *)reference phase:(UmbrellaKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(UmbrellaKtor_utilsPipelinePhase *)reference phase:(UmbrellaKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(UmbrellaKtor_utilsPipelinePhase *)phase block:(id<UmbrellaKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (NSArray<id<UmbrellaKotlinSuspendFunction2>> *)interceptorsForPhasePhase:(UmbrellaKtor_utilsPipelinePhase *)phase __attribute__((swift_name("interceptorsForPhase(phase:)")));
- (void)mergeFrom:(UmbrellaKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
- (void)mergePhasesFrom:(UmbrellaKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("mergePhases(from:)")));
- (void)resetFromFrom:(UmbrellaKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("resetFrom(from:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<UmbrellaKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property (readonly, getter=isEmpty_) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<UmbrellaKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface UmbrellaKtor_client_coreHttpReceivePipeline : UmbrellaKtor_utilsPipeline<UmbrellaKtor_client_coreHttpResponse *, UmbrellaKotlinUnit *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(UmbrellaKotlinArray<UmbrellaKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(UmbrellaKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<UmbrellaKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) UmbrellaKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface UmbrellaKtor_client_coreHttpRequestPipeline : UmbrellaKtor_utilsPipeline<id, UmbrellaKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(UmbrellaKotlinArray<UmbrellaKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(UmbrellaKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<UmbrellaKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) UmbrellaKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface UmbrellaKtor_client_coreHttpResponsePipeline : UmbrellaKtor_utilsPipeline<UmbrellaKtor_client_coreHttpResponseContainer *, UmbrellaKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(UmbrellaKotlinArray<UmbrellaKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(UmbrellaKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<UmbrellaKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) UmbrellaKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface UmbrellaKtor_client_coreHttpSendPipeline : UmbrellaKtor_utilsPipeline<id, UmbrellaKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(UmbrellaKotlinArray<UmbrellaKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(UmbrellaKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<UmbrellaKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) UmbrellaKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface UmbrellaKtor_client_coreProxyConfig : UmbrellaBase
- (instancetype)initWithUrl:(UmbrellaKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) UmbrellaKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol UmbrellaKotlinCoroutineContextKey
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol UmbrellaKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<UmbrellaKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface UmbrellaKotlinAbstractCoroutineContextKey<B, E> : UmbrellaBase <UmbrellaKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<UmbrellaKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<UmbrellaKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface UmbrellaKotlinx_coroutines_coreCoroutineDispatcherKey : UmbrellaKotlinAbstractCoroutineContextKey<id<UmbrellaKotlinContinuationInterceptor>, UmbrellaKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<UmbrellaKotlinCoroutineContextKey>)baseKey safeCast:(id<UmbrellaKotlinCoroutineContextElement> _Nullable (^)(id<UmbrellaKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol UmbrellaKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface UmbrellaKtor_httpUrlCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
- (id<UmbrellaKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("Ktor_httpParameters")))
@protocol UmbrellaKtor_httpParameters <UmbrellaKtor_utilsStringValues>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface UmbrellaKtor_httpURLProtocol : UmbrellaBase <UmbrellaKtor_ioJvmSerializable>
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (UmbrellaKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface UmbrellaKtor_httpHttpMethodCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));
- (UmbrellaKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));
@property (readonly) NSArray<UmbrellaKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) UmbrellaKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) UmbrellaKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) UmbrellaKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) UmbrellaKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) UmbrellaKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) UmbrellaKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) UmbrellaKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end

__attribute__((swift_name("KotlinMapEntry")))
@protocol UmbrellaKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface UmbrellaKtor_utilsAttributeKey<T> : UmbrellaBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString *)name type:(UmbrellaKtor_utilsTypeInfo *)type __attribute__((swift_name("init(name:type:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaKtor_utilsAttributeKey<T> *)doCopyName:(NSString *)name type:(UmbrellaKtor_utilsTypeInfo *)type __attribute__((swift_name("doCopy(name:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface UmbrellaKtor_httpHeaderValueWithParameters : UmbrellaBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<UmbrellaKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<UmbrellaKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface UmbrellaKtor_httpContentType : UmbrellaKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<UmbrellaKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<UmbrellaKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) UmbrellaKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(UmbrellaKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (UmbrellaKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (UmbrellaKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol UmbrellaKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol UmbrellaKotlinx_coroutines_coreChildHandle <UmbrellaKotlinx_coroutines_coreDisposableHandle>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (BOOL)childCancelledCause:(UmbrellaKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
@property (readonly) id<UmbrellaKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol UmbrellaKotlinx_coroutines_coreChildJob <UmbrellaKotlinx_coroutines_coreJob>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)parentCancelledParentJob:(id<UmbrellaKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end

__attribute__((swift_name("KotlinSequence")))
@protocol UmbrellaKotlinSequence
@required
- (id<UmbrellaKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause")))
@protocol UmbrellaKotlinx_coroutines_coreSelectClause
@required
@property (readonly) id clauseObject __attribute__((swift_name("clauseObject")));
@property (readonly) UmbrellaKotlinUnit *(^(^ _Nullable onCancellationConstructor)(id<UmbrellaKotlinx_coroutines_coreSelectInstance>, id _Nullable, id _Nullable))(UmbrellaKotlinThrowable *, id _Nullable, id<UmbrellaKotlinCoroutineContext>) __attribute__((swift_name("onCancellationConstructor")));
@property (readonly) id _Nullable (^processResFunc)(id, id _Nullable, id _Nullable) __attribute__((swift_name("processResFunc")));
@property (readonly) void (^regFunc)(id, id<UmbrellaKotlinx_coroutines_coreSelectInstance>, id _Nullable) __attribute__((swift_name("regFunc")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol UmbrellaKotlinx_coroutines_coreSelectClause0 <UmbrellaKotlinx_coroutines_coreSelectClause>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface UmbrellaKtor_httpHttpStatusCodeCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));
- (UmbrellaKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *TooEarly __attribute__((swift_name("TooEarly")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));
@property (readonly) NSArray<UmbrellaKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface UmbrellaKtor_utilsWeekDay : UmbrellaKotlinEnum<UmbrellaKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) UmbrellaKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) UmbrellaKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) UmbrellaKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) UmbrellaKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) UmbrellaKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) UmbrellaKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) UmbrellaKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) UmbrellaKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (UmbrellaKotlinArray<UmbrellaKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<UmbrellaKtor_utilsWeekDay *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface UmbrellaKtor_utilsMonth : UmbrellaKotlinEnum<UmbrellaKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) UmbrellaKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) UmbrellaKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) UmbrellaKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) UmbrellaKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) UmbrellaKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) UmbrellaKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) UmbrellaKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) UmbrellaKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) UmbrellaKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) UmbrellaKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) UmbrellaKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) UmbrellaKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) UmbrellaKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (UmbrellaKotlinArray<UmbrellaKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<UmbrellaKtor_utilsMonth *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface UmbrellaKtor_utilsGMTDateCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
- (id<UmbrellaKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@property (readonly) UmbrellaKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface UmbrellaKtor_httpHttpProtocolVersionCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));
- (UmbrellaKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));
- (UmbrellaKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));
@property (readonly) UmbrellaKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));
@property (readonly) UmbrellaKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));
@property (readonly) UmbrellaKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));
@property (readonly) UmbrellaKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));
@property (readonly) UmbrellaKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientPlugin")))
@protocol UmbrellaKtor_client_coreHttpClientPlugin
@required
- (void)installPlugin:(id)plugin scope:(UmbrellaKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(plugin:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) UmbrellaKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("Ktor_eventsEventDefinition")))
@interface UmbrellaKtor_eventsEventDefinition<T> : UmbrellaBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface UmbrellaKtor_utilsPipelinePhase : UmbrellaBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol UmbrellaKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol UmbrellaKotlinSuspendFunction2 <UmbrellaKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface UmbrellaKtor_client_coreHttpReceivePipelinePhases : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol UmbrellaKtor_httpHttpMessage
@required
@property (readonly) id<UmbrellaKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface UmbrellaKtor_client_coreHttpResponse : UmbrellaBase <UmbrellaKtor_httpHttpMessage, UmbrellaKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) UmbrellaKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<UmbrellaKtor_ioByteReadChannel> rawContent __attribute__((swift_name("rawContent")));
@property (readonly) UmbrellaKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) UmbrellaKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) UmbrellaKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) UmbrellaKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface UmbrellaKotlinUnit : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface UmbrellaKtor_client_coreHttpRequestPipelinePhases : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol UmbrellaKtor_httpHttpMessageBuilder
@required
@property (readonly) UmbrellaKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface UmbrellaKtor_client_coreHttpRequestBuilder : UmbrellaBase <UmbrellaKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) UmbrellaKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));
- (UmbrellaKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<UmbrellaKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<UmbrellaKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<UmbrellaKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (UmbrellaKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(UmbrellaKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (UmbrellaKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(UmbrellaKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(UmbrellaKtor_httpURLBuilder *, UmbrellaKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<UmbrellaKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property UmbrellaKtor_utilsTypeInfo * _Nullable bodyType __attribute__((swift_name("bodyType")));
@property (readonly) id<UmbrellaKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) UmbrellaKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property UmbrellaKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) UmbrellaKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface UmbrellaKtor_client_coreHttpResponsePipelinePhases : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface UmbrellaKtor_client_coreHttpResponseContainer : UmbrellaBase
- (instancetype)initWithExpectedType:(UmbrellaKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(UmbrellaKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) UmbrellaKtor_utilsTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface UmbrellaKtor_client_coreHttpClientCall : UmbrellaBase <UmbrellaKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithClient:(UmbrellaKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithClient:(UmbrellaKtor_client_coreHttpClient *)client requestData:(UmbrellaKtor_client_coreHttpRequestData *)requestData responseData:(UmbrellaKtor_client_coreHttpResponseData *)responseData __attribute__((swift_name("init(client:requestData:responseData:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyInfo:(UmbrellaKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("body(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyNullableInfo:(UmbrellaKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("bodyNullable(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<UmbrellaKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));
@property (readonly) id<UmbrellaKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) UmbrellaKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<UmbrellaKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property id<UmbrellaKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property UmbrellaKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface UmbrellaKtor_client_coreHttpSendPipelinePhases : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) UmbrellaKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol UmbrellaKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<UmbrellaKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<UmbrellaKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol UmbrellaKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<UmbrellaKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<UmbrellaKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol UmbrellaKotlinx_serialization_coreKSerializer <UmbrellaKotlinx_serialization_coreSerializationStrategy, UmbrellaKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface UmbrellaKtor_httpURLProtocolCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));
- (UmbrellaKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));
@property (readonly) UmbrellaKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));
@property (readonly) UmbrellaKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));
@property (readonly) UmbrellaKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));
@property (readonly) UmbrellaKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));
@property (readonly) UmbrellaKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));
@property (readonly) NSDictionary<NSString *, UmbrellaKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsTypeInfo")))
@interface UmbrellaKtor_utilsTypeInfo : UmbrellaBase
- (instancetype)initWithType:(id<UmbrellaKotlinKClass>)type kotlinType:(id<UmbrellaKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithType:(id<UmbrellaKotlinKClass>)type reifiedType:(id<UmbrellaKotlinKType>)reifiedType kotlinType:(id<UmbrellaKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use constructor without reifiedType parameter.")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<UmbrellaKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<UmbrellaKotlinKClass> type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface UmbrellaKtor_httpHeaderValueParam : UmbrellaBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("init(name:value:escapeValue:)"))) __attribute__((objc_designated_initializer));
- (UmbrellaKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("doCopy(name:value:escapeValue:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL escapeValue __attribute__((swift_name("escapeValue")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface UmbrellaKtor_httpHeaderValueWithParametersCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<UmbrellaKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface UmbrellaKtor_httpContentTypeCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));
- (UmbrellaKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));
@property (readonly) UmbrellaKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol UmbrellaKotlinx_coroutines_coreParentJob <UmbrellaKotlinx_coroutines_coreJob>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (UmbrellaKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol UmbrellaKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnCompletionDisposableHandle:(id<UmbrellaKotlinx_coroutines_coreDisposableHandle>)disposableHandle __attribute__((swift_name("disposeOnCompletion(disposableHandle:)")));
- (void)selectInRegistrationPhaseInternalResult:(id _Nullable)internalResult __attribute__((swift_name("selectInRegistrationPhase(internalResult:)")));
- (BOOL)trySelectClauseObject:(id)clauseObject result:(id _Nullable)result __attribute__((swift_name("trySelect(clauseObject:result:)")));
@property (readonly) id<UmbrellaKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface UmbrellaKtor_utilsWeekDayCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));
- (UmbrellaKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (UmbrellaKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface UmbrellaKtor_utilsMonthCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));
- (UmbrellaKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (UmbrellaKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol UmbrellaKtor_ioByteReadChannel
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitContentMin:(int32_t)min completionHandler:(void (^)(UmbrellaBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("awaitContent(min:completionHandler:)")));
- (void)cancelCause_:(UmbrellaKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));
@property (readonly) UmbrellaKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) id<UmbrellaKotlinx_io_coreSource> readBuffer __attribute__((swift_name("readBuffer")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@protocol UmbrellaKtor_utilsStringValuesBuilder
@required
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<UmbrellaKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<UmbrellaKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<UmbrellaKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<UmbrellaKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilderImpl")))
@interface UmbrellaKtor_utilsStringValuesBuilderImpl : UmbrellaBase <UmbrellaKtor_utilsStringValuesBuilder>
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<UmbrellaKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<UmbrellaKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<UmbrellaKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<UmbrellaKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) UmbrellaMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface UmbrellaKtor_httpHeadersBuilder : UmbrellaKtor_utilsStringValuesBuilderImpl
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<UmbrellaKtor_httpHeaders>)build __attribute__((swift_name("build()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface UmbrellaKtor_client_coreHttpRequestBuilderCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface UmbrellaKtor_httpURLBuilder : UmbrellaBase
- (instancetype)initWithProtocol:(UmbrellaKtor_httpURLProtocol * _Nullable)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password pathSegments:(NSArray<NSString *> *)pathSegments parameters:(id<UmbrellaKtor_httpParameters>)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:pathSegments:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));
- (UmbrellaKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property id<UmbrellaKtor_httpParametersBuilder> encodedParameters __attribute__((swift_name("encodedParameters")));
@property NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property NSArray<NSString *> *encodedPathSegments __attribute__((swift_name("encodedPathSegments")));
@property NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) id<UmbrellaKtor_httpParametersBuilder> parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property int32_t port __attribute__((swift_name("port")));
@property UmbrellaKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property UmbrellaKtor_httpURLProtocol * _Nullable protocolOrNull __attribute__((swift_name("protocolOrNull")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface UmbrellaKtor_client_coreHttpClientCallCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol UmbrellaKtor_client_coreHttpRequest <UmbrellaKtor_httpHttpMessage, UmbrellaKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<UmbrellaKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) UmbrellaKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) UmbrellaKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) UmbrellaKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) UmbrellaKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol UmbrellaKotlinx_serialization_coreEncoder
@required
- (id<UmbrellaKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<UmbrellaKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<UmbrellaKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<UmbrellaKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<UmbrellaKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) UmbrellaKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol UmbrellaKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<UmbrellaKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<UmbrellaKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) UmbrellaKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol UmbrellaKotlinx_serialization_coreDecoder
@required
- (id<UmbrellaKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<UmbrellaKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (UmbrellaKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<UmbrellaKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<UmbrellaKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) UmbrellaKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol UmbrellaKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol UmbrellaKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol UmbrellaKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol UmbrellaKotlinKClass <UmbrellaKotlinKDeclarationContainer, UmbrellaKotlinKAnnotatedElement, UmbrellaKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((swift_name("KotlinKType")))
@protocol UmbrellaKotlinKType
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) NSArray<UmbrellaKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) id<UmbrellaKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end

__attribute__((swift_name("Kotlinx_io_coreRawSource")))
@protocol UmbrellaKotlinx_io_coreRawSource <UmbrellaKotlinAutoCloseable>
@required
- (int64_t)readAtMostToSink:(UmbrellaKotlinx_io_coreBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readAtMostTo(sink:byteCount:)")));
@end

__attribute__((swift_name("Kotlinx_io_coreSource")))
@protocol UmbrellaKotlinx_io_coreSource <UmbrellaKotlinx_io_coreRawSource>
@required
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (id<UmbrellaKotlinx_io_coreSource>)peek __attribute__((swift_name("peek()")));
- (int32_t)readAtMostToSink:(UmbrellaKotlinByteArray *)sink startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("readAtMostTo(sink:startIndex:endIndex:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (void)readToSink:(id<UmbrellaKotlinx_io_coreRawSink>)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readTo(sink:byteCount:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (int64_t)transferToSink:(id<UmbrellaKotlinx_io_coreRawSink>)sink __attribute__((swift_name("transferTo(sink:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) UmbrellaKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface UmbrellaKtor_httpURLBuilderCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParametersBuilder")))
@protocol UmbrellaKtor_httpParametersBuilder <UmbrellaKtor_utilsStringValuesBuilder>
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol UmbrellaKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<UmbrellaKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<UmbrellaKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<UmbrellaKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) UmbrellaKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface UmbrellaKotlinx_serialization_coreSerializersModule : UmbrellaBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<UmbrellaKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<UmbrellaKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<UmbrellaKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<UmbrellaKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<UmbrellaKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<UmbrellaKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<UmbrellaKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<UmbrellaKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol UmbrellaKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface UmbrellaKotlinx_serialization_coreSerialKind : UmbrellaBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol UmbrellaKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<UmbrellaKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<UmbrellaKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<UmbrellaKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<UmbrellaKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) UmbrellaKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface UmbrellaKotlinNothing : UmbrellaBase
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface UmbrellaKotlinKTypeProjection : UmbrellaBase
- (instancetype)initWithVariance:(UmbrellaKotlinKVariance * _Nullable)variance type:(id<UmbrellaKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) UmbrellaKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (UmbrellaKotlinKTypeProjection *)doCopyVariance:(UmbrellaKotlinKVariance * _Nullable)variance type:(id<UmbrellaKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<UmbrellaKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) UmbrellaKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface UmbrellaKotlinByteArray : UmbrellaBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(UmbrellaByte *(^)(UmbrellaInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (UmbrellaKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_io_coreRawSink")))
@protocol UmbrellaKotlinx_io_coreRawSink <UmbrellaKotlinAutoCloseable>
@required
- (void)flush __attribute__((swift_name("flush()")));
- (void)writeSource:(UmbrellaKotlinx_io_coreBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
@end

__attribute__((swift_name("Kotlinx_io_coreSink")))
@protocol UmbrellaKotlinx_io_coreSink <UmbrellaKotlinx_io_coreRawSink>
@required
- (void)emit __attribute__((swift_name("emit()")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
- (void)hintEmit __attribute__((swift_name("hintEmit()")));
- (int64_t)transferFromSource:(id<UmbrellaKotlinx_io_coreRawSource>)source __attribute__((swift_name("transferFrom(source:)")));
- (void)writeSource:(id<UmbrellaKotlinx_io_coreRawSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (void)writeSource:(UmbrellaKotlinByteArray *)source startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("write(source:startIndex:endIndex:)")));
- (void)writeByteByte:(int8_t)byte __attribute__((swift_name("writeByte(byte:)")));
- (void)writeIntInt:(int32_t)int_ __attribute__((swift_name("writeInt(int:)")));
- (void)writeLongLong:(int64_t)long_ __attribute__((swift_name("writeLong(long:)")));
- (void)writeShortShort:(int16_t)short_ __attribute__((swift_name("writeShort(short:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) UmbrellaKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_io_coreBuffer")))
@interface UmbrellaKotlinx_io_coreBuffer : UmbrellaBase <UmbrellaKotlinx_io_coreSource, UmbrellaKotlinx_io_coreSink>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (UmbrellaKotlinx_io_coreBuffer *)doCopy __attribute__((swift_name("doCopy()")));
- (void)doCopyToOut:(UmbrellaKotlinx_io_coreBuffer *)out startIndex:(int64_t)startIndex endIndex:(int64_t)endIndex __attribute__((swift_name("doCopyTo(out:startIndex:endIndex:)")));
- (void)emit __attribute__((swift_name("emit()")));
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (void)flush __attribute__((swift_name("flush()")));
- (int8_t)getPosition:(int64_t)position __attribute__((swift_name("get(position:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
- (void)hintEmit __attribute__((swift_name("hintEmit()")));
- (id<UmbrellaKotlinx_io_coreSource>)peek __attribute__((swift_name("peek()")));
- (int64_t)readAtMostToSink:(UmbrellaKotlinx_io_coreBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readAtMostTo(sink:byteCount:)")));
- (int32_t)readAtMostToSink:(UmbrellaKotlinByteArray *)sink startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("readAtMostTo(sink:startIndex:endIndex:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (void)readToSink:(id<UmbrellaKotlinx_io_coreRawSink>)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readTo(sink:byteCount:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int64_t)transferFromSource:(id<UmbrellaKotlinx_io_coreRawSource>)source __attribute__((swift_name("transferFrom(source:)")));
- (int64_t)transferToSink:(id<UmbrellaKotlinx_io_coreRawSink>)sink __attribute__((swift_name("transferTo(sink:)")));
- (void)writeSource:(UmbrellaKotlinx_io_coreBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (void)writeSource:(id<UmbrellaKotlinx_io_coreRawSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (void)writeSource:(UmbrellaKotlinByteArray *)source startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("write(source:startIndex:endIndex:)")));
- (void)writeByteByte:(int8_t)byte __attribute__((swift_name("writeByte(byte:)")));
- (void)writeIntInt:(int32_t)int_ __attribute__((swift_name("writeInt(int:)")));
- (void)writeLongLong:(int64_t)long_ __attribute__((swift_name("writeLong(long:)")));
- (void)writeShortShort:(int16_t)short_ __attribute__((swift_name("writeShort(short:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) UmbrellaKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol UmbrellaKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<UmbrellaKotlinKClass>)kClass provider:(id<UmbrellaKotlinx_serialization_coreKSerializer> (^)(NSArray<id<UmbrellaKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<UmbrellaKotlinKClass>)kClass serializer:(id<UmbrellaKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<UmbrellaKotlinKClass>)baseClass actualClass:(id<UmbrellaKotlinKClass>)actualClass actualSerializer:(id<UmbrellaKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<UmbrellaKotlinKClass>)baseClass defaultDeserializerProvider:(id<UmbrellaKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<UmbrellaKotlinKClass>)baseClass defaultDeserializerProvider:(id<UmbrellaKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<UmbrellaKotlinKClass>)baseClass defaultSerializerProvider:(id<UmbrellaKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface UmbrellaKotlinKVariance : UmbrellaKotlinEnum<UmbrellaKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) UmbrellaKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) UmbrellaKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) UmbrellaKotlinKVariance *out __attribute__((swift_name("out")));
+ (UmbrellaKotlinArray<UmbrellaKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<UmbrellaKotlinKVariance *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface UmbrellaKotlinKTypeProjectionCompanion : UmbrellaBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) UmbrellaKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (UmbrellaKotlinKTypeProjection *)contravariantType:(id<UmbrellaKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (UmbrellaKotlinKTypeProjection *)covariantType:(id<UmbrellaKotlinKType>)type __attribute__((swift_name("covariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (UmbrellaKotlinKTypeProjection *)invariantType:(id<UmbrellaKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) UmbrellaKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface UmbrellaKotlinByteIterator : UmbrellaBase <UmbrellaKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (UmbrellaByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
